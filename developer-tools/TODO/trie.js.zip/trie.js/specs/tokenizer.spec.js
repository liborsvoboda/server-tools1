describe('Tokinizers', function() {

  'use strict';

  describe('Whitespace Tokinizer', function() {

    xit('should return words from a sentence', function() {
      // (5).should.equal(5);
    });
  });
});