const config = {
  shouldOptimizeClientRects: true,
  optimizeSelectionFlickering: true,
};

export default config;
