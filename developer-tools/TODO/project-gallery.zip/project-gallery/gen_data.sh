#!/bin/bash
python3 data/generator.py --token="$(< token)" --json=data/data.json